<?php

    include './cTop.html';
?>


<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
  <a class="nav-link" href="tables.html">
    <i class="fa fa-fw fa-table"></i>
    <span class="nav-link-text">Tables</span>
  </a>
</li>

</ul>





<?php
    include './cBottom.html';
?>
